
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.casinomod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.Block;
import net.minecraft.core.registries.BuiltInRegistries;

import net.mcreator.casinomod.block.entity.RouletteTableBlockEntity;
import net.mcreator.casinomod.block.entity.LotteryBlockBlockEntity;
import net.mcreator.casinomod.block.entity.BoothBlockEntity;
import net.mcreator.casinomod.CasinoModMod;

@EventBusSubscriber(bus = EventBusSubscriber.Bus.MOD)
public class CasinoModModBlockEntities {
	public static final DeferredRegister<BlockEntityType<?>> REGISTRY = DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, CasinoModMod.MODID);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> BOOTH = register("booth", CasinoModModBlocks.BOOTH, BoothBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> ROULETTE_TABLE = register("roulette_table", CasinoModModBlocks.ROULETTE_TABLE, RouletteTableBlockEntity::new);
	public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> LOTTERY_BLOCK = register("lottery_block", CasinoModModBlocks.LOTTERY_BLOCK, LotteryBlockBlockEntity::new);

	// Start of user code block custom block entities
	// End of user code block custom block entities
	private static DeferredHolder<BlockEntityType<?>, BlockEntityType<?>> register(String registryname, DeferredHolder<Block, Block> block, BlockEntityType.BlockEntitySupplier<?> supplier) {
		return REGISTRY.register(registryname, () -> new BlockEntityType(supplier, block.get()));
	}

	@SubscribeEvent
	public static void registerCapabilities(RegisterCapabilitiesEvent event) {
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, BOOTH.get(), (blockEntity, side) -> ((BoothBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, ROULETTE_TABLE.get(), (blockEntity, side) -> ((RouletteTableBlockEntity) blockEntity).getItemHandler());
		event.registerBlockEntity(Capabilities.ItemHandler.BLOCK, LOTTERY_BLOCK.get(), (blockEntity, side) -> ((LotteryBlockBlockEntity) blockEntity).getItemHandler());
	}
}
