
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.casinomod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.casinomod.item.ChipsItem;
import net.mcreator.casinomod.CasinoModMod;

import java.util.function.Function;

public class CasinoModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(CasinoModMod.MODID);
	public static final DeferredItem<Item> CHIPS = register("chips", ChipsItem::new);
	public static final DeferredItem<Item> BOOTH = block(CasinoModModBlocks.BOOTH);
	public static final DeferredItem<Item> ROULETTE_TABLE = block(CasinoModModBlocks.ROULETTE_TABLE);
	public static final DeferredItem<Item> LOTTERY_BLOCK = block(CasinoModModBlocks.LOTTERY_BLOCK);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return REGISTRY.registerItem(block.getId().getPath(), properties -> new BlockItem(block.get(), properties), new Item.Properties());
	}
}
