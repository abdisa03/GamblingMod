
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.casinomod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.extensions.IMenuTypeExtension;

import net.minecraft.world.inventory.MenuType;
import net.minecraft.core.registries.Registries;

import net.mcreator.casinomod.world.inventory.SlotsGUIMenu;
import net.mcreator.casinomod.CasinoModMod;

public class CasinoModModMenus {
	public static final DeferredRegister<MenuType<?>> REGISTRY = DeferredRegister.create(Registries.MENU, CasinoModMod.MODID);
	public static final DeferredHolder<MenuType<?>, MenuType<SlotsGUIMenu>> SLOTS_GUI = REGISTRY.register("slots_gui", () -> IMenuTypeExtension.create(SlotsGUIMenu::new));
}
